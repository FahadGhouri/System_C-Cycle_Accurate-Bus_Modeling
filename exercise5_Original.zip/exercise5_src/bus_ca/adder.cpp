// file adder.cpp
#include "adder.h"
void Adder::add()
{
  s = x + y;
}
